export const formInput = document.getElementById('description');
export const showMsg = document.querySelector('.display-message');
export const btnSubmit = document.querySelector('.btn-submit');
export const todoContainer = document.querySelector('.todo-items-gropu');
export const todoItemsDes = document.querySelectorAll('.todo-des');
export const filterButton = document.querySelector('.btn-clear-all');